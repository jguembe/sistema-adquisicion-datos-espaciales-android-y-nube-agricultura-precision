HereGPSLocation
===============

Android application which gives us GPS coordinates
